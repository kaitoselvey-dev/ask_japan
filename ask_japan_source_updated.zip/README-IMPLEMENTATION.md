# Ask Japan website update

## Included
- English-language homepage, navigation, footer, and information pages.
- Free question form at `/services/ask`: name and question, review step, confirmation, and a generated demo case number.
- Paid support request at `/services/request`: destination, travel details, selectable service types, per-service detail fields, budget, and optional early-response request (+$10).
- Request review and confirmation flow, with a displayed response window (normally within 2 days; within 12 hours when early response is selected).

## Important prototype limitation
The forms are front-end demonstrations only. They do not send email, persist requests, or create case numbers in a backend. The case number is generated in the browser. Before launch, connect the forms to a backend/email workflow and generate persistent case numbers server-side.

## Pricing currently shown
- Free: simple questions, indirect research, and questions about paid services; email replies only.
- Phone research: $10.
- Itinerary planning and support: $20 per day.
- In-person research: $100 plus travel expenses.
- Real-time travel support: $30 per case or $50 per day.
- Early response request: +$10 (target response within 12 hours).
- Custom support: quote on request.
- Combined-service discounts may be available. Rush fees may apply and should be confirmed before the customer commits.

## Run locally
Use the existing package scripts: `npm install`, `npm run dev`.
